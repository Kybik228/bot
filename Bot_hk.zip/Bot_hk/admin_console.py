import sqlite3
from datetime import datetime
import os
import sys

class ConsoleAdmin:
    def __init__(self, db_name='bot_database.db'):
        self.db_name = db_name
        self.conn = sqlite3.connect(db_name)
        self.conn.row_factory = sqlite3.Row
    
    def clear_screen(self):
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def show_header(self):
        self.clear_screen()
        print("=" * 60)
        print("           ChatGPT - АДМИН ПАНЕЛЬ")
        print("=" * 60)
        print()
    
    def show_menu(self):
        self.show_header()
        print("📊 МЕНЮ АДМИНИСТРАТОРА:")
        print("1. 📈 Общая статистика системы")
        print("2. 👥 Список всех пользователей")
        print("3. 💬 Последние сообщения")
        print("4. 🔍 Поиск пользователя по ID")
        print("5. 🔎 Поиск по сообщениям")
        print("6. 📤 Экспорт данных пользователя")
        print("7. 🗑 Управление данными")
        print("0. 🚪 Выход")
        print()
    
    def get_total_stats(self):
        cursor = self.conn.cursor()
        
        cursor.execute('SELECT COUNT(*) FROM users')
        total_users = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(*) FROM messages')
        total_messages = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(DISTINCT user_id) FROM messages WHERE timestamp > datetime("now", "-7 days")')
        active_users_7d = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(DISTINCT user_id) FROM messages WHERE timestamp > datetime("now", "-1 days")')
        active_users_1d = cursor.fetchone()[0]
        
        cursor.execute('''
            SELECT date(timestamp) as day, COUNT(*) as count
            FROM messages
            WHERE timestamp > datetime("now", "-30 days")
            GROUP BY day
            ORDER BY day DESC
            LIMIT 7
        ''')
        daily_stats = cursor.fetchall()
        
        return {
            'total_users': total_users,
            'total_messages': total_messages,
            'active_users_7d': active_users_7d,
            'active_users_1d': active_users_1d,
            'daily_stats': daily_stats
        }
    
    def show_stats(self):
        self.show_header()
        print("📊 СТАТИСТИКА СИСТЕМЫ ChatGPT")
        print("-" * 60)
        
        stats = self.get_total_stats()
        
        print(f"👥 Всего пользователей: {stats['total_users']}")
        print(f"💬 Всего сообщений: {stats['total_messages']}")
        print(f"📈 Активных за 7 дней: {stats['active_users_7d']}")
        print(f"📈 Активных за 24 часа: {stats['active_users_1d']}")
        
        print("\n📅 АКТИВНОСТЬ ПО ДНЯМ (последние 7 дней):")
        print("-" * 40)
        for day in stats['daily_stats']:
            print(f"  {day[0]}: {day[1]} сообщений")
        
        input("\nНажмите Enter для продолжения...")
    
    def show_users(self):
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT user_id, username, first_name, last_name, 
                   created_at, last_active, message_count
            FROM users
            ORDER BY last_active DESC
            LIMIT 50
        ''')
        
        users = cursor.fetchall()
        
        self.show_header()
        print("👥 СПИСОК ПОЛЬЗОВАТЕЛЕЙ ChatGPT")
        print("-" * 60)
        
        for i, user in enumerate(users, 1):
            print(f"{i:3}. ID: {user['user_id']}")
            print(f"     👤 Имя: {user['first_name']} {user['last_name'] if user['last_name'] else ''}")
            print(f"     📱 Username: @{user['username'] if user['username'] else 'не указан'}")
            print(f"     📊 Сообщений: {user['message_count']}")
            print(f"     ⏰ Регистрация: {user['created_at']}")
            print(f"     🕐 Последняя активность: {user['last_active'][:19] if user['last_active'] else 'никогда'}")
            print()
        
        print(f"📋 Всего показано: {len(users)} пользователей")
        input("\nНажмите Enter для продолжения...")
    
    def show_recent_messages(self):
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT m.user_id, u.first_name, u.username, m.role, m.message_text, m.timestamp
            FROM messages m
            JOIN users u ON m.user_id = u.user_id
            ORDER BY m.timestamp DESC
            LIMIT 30
        ''')
        
        messages = cursor.fetchall()
        
        self.show_header()
        print("💬 ПОСЛЕДНИЕ СООБЩЕНИЯ В СИСТЕМЕ")
        print("-" * 60)
        
        for i, msg in enumerate(messages, 1):
            user_id = msg['user_id']
            first_name = msg['first_name']
            username = msg['username']
            role = msg['role']
            message_text = msg['message_text']
            timestamp = msg['timestamp']
            
            user_display = first_name or username or f"ID:{user_id}"
            role_display = "👤 ПОЛЬЗОВАТЕЛЬ" if role == 'user' else "🤖 ChatGPT"
            
            print(f"{i:2}. {role_display} {user_display}")
            print(f"    💬 {message_text[:70]}{'...' if len(message_text) > 70 else ''}")
            print(f"    📅 {timestamp[:19]}")
            print()
        
        input("\nНажмите Enter для продолжения...")
    
    def search_user_by_id(self):
        self.show_header()
        print("🔍 ПОИСК ПОЛЬЗОВАТЕЛЯ ПО ID")
        print("-" * 60)
        
        try:
            user_id = input("Введите ID пользователя: ").strip()
            
            if not user_id:
                print("❌ ID не может быть пустым")
                input("\nНажмите Enter для продолжения...")
                return
            
            cursor = self.conn.cursor()
            cursor.execute('''
                SELECT u.*, us.temperature, us.personality
                FROM users u
                LEFT JOIN user_settings us ON u.user_id = us.user_id
                WHERE u.user_id = ?
            ''', (user_id,))
            
            user = cursor.fetchone()
            
            if not user:
                print(f"❌ Пользователь с ID {user_id} не найден")
                input("\nНажмите Enter для продолжения...")
                return
            
            print(f"\n👤 ИНФОРМАЦИЯ О ПОЛЬЗОВАТЕЛЕ:")
            print(f"  🆔 ID: {user['user_id']}")
            print(f"  👤 Имя: {user['first_name']} {user['last_name'] if user['last_name'] else ''}")
            print(f"  📱 Username: @{user['username'] if user['username'] else 'не указан'}")
            print(f"  📅 Дата регистрации: {user['created_at']}")
            print(f"  🕐 Последняя активность: {user['last_active'][:19] if user['last_active'] else 'никогда'}")
            print(f"  📊 Сообщений: {user['message_count']}")
            print(f"  🧠 Личность: {user['personality']}")
            print(f"  🌡 Температура: {user['temperature']}")
            
            cursor.execute('''
                SELECT role, message_text, timestamp
                FROM messages
                WHERE user_id = ?
                ORDER BY timestamp DESC
                LIMIT 10
            ''', (user_id,))
            
            messages = cursor.fetchall()
            
            if messages:
                print(f"\n💬 ПОСЛЕДНИЕ СООБЩЕНИЯ ПОЛЬЗОВАТЕЛЯ:")
                for role, text, timestamp in messages:
                    role_text = "👤 ПОЛЬЗОВАТЕЛЬ" if role == "user" else "🤖 ChatGPT"
                    short_text = text[:80] + "..." if len(text) > 80 else text
                    print(f"  {role_text} ({timestamp[:19]}):")
                    print(f"    {short_text}")
            
        except Exception as e:
            print(f"❌ Ошибка: {e}")
        
        input("\nНажмите Enter для продолжения...")
    
    def search_messages(self):
        self.show_header()
        print("🔎 ПОИСК ПО СООБЩЕНИЯМ ChatGPT")
        print("-" * 60)
        
        keyword = input("Введите ключевое слово для поиска: ").strip()
        
        if not keyword:
            print("❌ Ключевое слово не может быть пустым")
            input("\nНажмите Enter для продолжения...")
            return
        
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT m.user_id, u.first_name, u.username, m.role, m.message_text, m.timestamp
            FROM messages m
            JOIN users u ON m.user_id = u.user_id
            WHERE m.message_text LIKE ?
            ORDER BY m.timestamp DESC
            LIMIT 30
        ''', (f'%{keyword}%',))
        
        results = cursor.fetchall()
        
        self.show_header()
        print(f"🔎 РЕЗУЛЬТАТЫ ПОИСКА: '{keyword}'")
        print("-" * 60)
        
        if not results:
            print("❌ Сообщений не найдено")
        else:
            print(f"📊 Найдено сообщений: {len(results)}\n")
            
            for i, msg in enumerate(results, 1):
                user_id = msg['user_id']
                first_name = msg['first_name']
                username = msg['username']
                role = msg['role']
                message_text = msg['message_text']
                timestamp = msg['timestamp']
                
                role_emoji = "👤" if role == "user" else "🤖"
                user_display = first_name or username or f"ID:{user_id}"
                
                text = message_text
                keyword_lower = keyword.lower()
                text_lower = text.lower()
                
                if keyword_lower in text_lower:
                    idx = text_lower.find(keyword_lower)
                    start = max(0, idx - 30)
                    end = min(len(text), idx + len(keyword) + 30)
                    snippet = text[start:end]
                    if start > 0:
                        snippet = "..." + snippet
                    if end < len(text):
                        snippet = snippet + "..."
                    
                    # Подсветка ключевого слова
                    import re
                    pattern = re.compile(re.escape(keyword), re.IGNORECASE)
                    snippet = pattern.sub(f"\033[91m{keyword}\033[0m", snippet)
                else:
                    snippet = text[:80] + "..." if len(text) > 80 else text
                
                print(f"{i:2}. {role_emoji} {user_display}")
                print(f"    💬 {snippet}")
                print(f"    📅 {timestamp[:19]}")
                print()
        
        input("\nНажмите Enter для продолжения...")
    
    def export_user_data(self):
        self.show_header()
        print("📤 ЭКСПОРТ ДАННЫХ ПОЛЬЗОВАТЕЛЯ")
        print("-" * 60)
        
        try:
            user_id = input("Введите ID пользователя: ").strip()
            
            if not user_id:
                print("❌ ID не может быть пустым")
                input("\nНажмите Enter для продолжения...")
                return
            
            cursor = self.conn.cursor()
            
            cursor.execute('''
                SELECT u.*, us.temperature, us.personality
                FROM users u
                LEFT JOIN user_settings us ON u.user_id = us.user_id
                WHERE u.user_id = ?
            ''', (user_id,))
            
            user = cursor.fetchone()
            
            if not user:
                print(f"❌ Пользователь с ID {user_id} не найден")
                input("\nНажмите Enter для продолжения...")
                return
            
            cursor.execute('''
                SELECT role, message_text, timestamp
                FROM messages
                WHERE user_id = ?
                ORDER BY timestamp
            ''', (user_id,))
            
            messages = cursor.fetchall()
            
            filename = f"chatgpt_user_{user_id}_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
            
            with open(filename, 'w', encoding='utf-8') as f:
                f.write("=" * 60 + "\n")
                f.write(f"ЭКСПОРТ ДАННЫХ ПОЛЬЗОВАТЕЛЯ ChatGPT\n")
                f.write("=" * 60 + "\n\n")
                
                f.write("👤 ИНФОРМАЦИЯ О ПОЛЬЗОВАТЕЛЕ:\n")
                f.write(f"  ID: {user['user_id']}\n")
                f.write(f"  Имя: {user['first_name']} {user['last_name'] if user['last_name'] else ''}\n")
                f.write(f"  Username: @{user['username'] if user['username'] else 'не указан'}\n")
                f.write(f"  Дата регистрации: {user['created_at']}\n")
                f.write(f"  Последняя активность: {user['last_active'][:19] if user['last_active'] else 'никогда'}\n")
                f.write(f"  Сообщений: {user['message_count']}\n")
                f.write(f"  Личность: {user['personality']}\n")
                f.write(f"  Температура: {user['temperature']}\n\n")
                
                f.write("💬 ИСТОРИЯ ДИАЛОГА:\n")
                f.write("-" * 40 + "\n")
                
                for role, text, timestamp in messages:
                    role_text = "ПОЛЬЗОВАТЕЛЬ" if role == "user" else "ChatGPT"
                    f.write(f"\n[{timestamp[:19]}] {role_text}:\n")
                    f.write(f"{text}\n")
                    f.write("-" * 40 + "\n")
            
            print(f"✅ Данные успешно экспортированы в файл: {filename}")
            print(f"📊 Всего сообщений: {len(messages)}")
            
        except Exception as e:
            print(f"❌ Ошибка при экспорте: {e}")
        
        input("\nНажмите Enter для продолжения...")
    
    def manage_data(self):
        self.show_header()
        print("🗑 УПРАВЛЕНИЕ ДАННЫМИ")
        print("-" * 60)
        print("⚠️  ВНИМАНИЕ: Все действия необратимы!")
        print()
        print("1. Очистить историю сообщений (старше 30 дней)")
        print("2. Удалить неактивных пользователей")
        print("3. Создать резервную копию базы данных")
        print("0. Назад")
        print()
        
        choice = input("Выберите действие: ").strip()
        
        if choice == "1":
            confirm = input("Удалить сообщения старше 30 дней? (да/нет): ").lower()
            if confirm == 'да':
                cursor = self.conn.cursor()
                cursor.execute('DELETE FROM messages WHERE timestamp < datetime("now", "-30 days")')
                deleted = cursor.rowcount
                self.conn.commit()
                print(f"✅ Удалено {deleted} старых сообщений")
        
        elif choice == "2":
            days = input("Удалить пользователей неактивных более N дней: ").strip()
            try:
                days = int(days)
                confirm = input(f"Удалить пользователей неактивных более {days} дней? (да/нет): ").lower()
                if confirm == 'да':
                    cursor = self.conn.cursor()
                    cursor.execute('''
                        DELETE FROM users 
                        WHERE last_active < datetime('now', ?) 
                        AND user_id NOT IN (SELECT user_id FROM user_settings WHERE personality != 'Нейтральный')
                    ''', (f'-{days} days',))
                    deleted = cursor.rowcount
                    self.conn.commit()
                    print(f"✅ Удалено {deleted} неактивных пользователей")
            except ValueError:
                print("❌ Неверное количество дней")
        
        elif choice == "3":
            import shutil
            backup_name = f"chatgpt_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
            shutil.copy2('bot_database.db', backup_name)
            print(f"✅ Резервная копия создана: {backup_name}")
        
        input("\nНажмите Enter для продолжения...")
    
    def run(self):
        while True:
            try:
                self.show_menu()
                choice = input("Выберите действие (0-7): ").strip()
                
                if choice == "0":
                    print("\n👋 Выход из админ-панели ChatGPT...")
                    break
                
                elif choice == "1":
                    self.show_stats()
                
                elif choice == "2":
                    self.show_users()
                
                elif choice == "3":
                    self.show_recent_messages()
                
                elif choice == "4":
                    self.search_user_by_id()
                
                elif choice == "5":
                    self.search_messages()
                
                elif choice == "6":
                    self.export_user_data()
                
                elif choice == "7":
                    self.manage_data()
                
                else:
                    print("❌ Неверный выбор")
                    input("\nНажмите Enter для продолжения...")
                    
            except KeyboardInterrupt:
                print("\n\n👋 Выход из админ-панели...")
                break
            except Exception as e:
                print(f"❌ Ошибка: {e}")
                input("\nНажмите Enter для продолжения...")
        
        self.conn.close()

if __name__ == "__main__":
    if not os.path.exists('bot_database.db'):
        print("❌ База данных не найдена!")
        print("Сначала запустите бота для создания базы данных.")
        sys.exit(1)
    
    admin = ConsoleAdmin()
    admin.run()