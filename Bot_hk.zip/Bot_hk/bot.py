import logging
import asyncio
import time
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import (
    Application, CommandHandler, MessageHandler, CallbackQueryHandler,
    ContextTypes, filters
)
import aiohttp
from database import Database
import os
from dotenv import load_dotenv

# Загружаем переменные окружения
load_dotenv()

# Конфигурация
TELEGRAM_TOKEN = os.getenv('TELEGRAM_TOKEN')
DEEPSEEK_API_KEY = os.getenv('DEEPSEEK_API_KEY')
ADMIN_IDS = [int(id.strip()) for id in os.getenv('ADMIN_IDS', '').split(',') if id.strip()]

# Проверка наличия обязательных переменных
if not TELEGRAM_TOKEN:
    raise ValueError("TELEGRAM_TOKEN не установлен в .env файле")
if not DEEPSEEK_API_KEY:
    print("⚠️ ВНИМАНИЕ: DEEPSEEK_API_KEY не установлен. Бот будет работать в тестовом режиме.")
    TEST_MODE = True
else:
    TEST_MODE = False

# Настройки по умолчанию
DEFAULT_MODEL = "deepseek-chat"
DEFAULT_TEMPERATURE = 0.7
DEFAULT_MAX_TOKENS = 2048
DEFAULT_SYSTEM_PROMPT = "Ты - ChatGPT, продвинутый AI-ассистент созданный OpenAI. Ты помогаешь пользователям решать задачи, отвечать на вопросы и поддерживаешь беседу. Будь полезным, дружелюбным и профессиональным."

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Инициализация базы данных
db = Database()

# Проверка прав администратора
def is_admin(user_id):
    return user_id in ADMIN_IDS

# ============ КЛАВИАТУРЫ ============

def get_main_keyboard():
    """Основная клавиатура (ReplyKeyboardMarkup)"""
    keyboard = [
        [KeyboardButton("⚙️ Настройки"), KeyboardButton("❓ Помощь")],
        [KeyboardButton("🌡 Температура"), KeyboardButton("🧠 Личность")],
        [KeyboardButton("📜 История"), KeyboardButton("🗑 Очистить")],
        [KeyboardButton("📊 О боте"), KeyboardButton("💬 Новый чат")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)  # Убрали persistent=True

def get_settings_keyboard():
    """Клавиатура настроек (InlineKeyboardMarkup)"""
    keyboard = [
        [InlineKeyboardButton("🌡 Изменить температуру", callback_data="set_temp")],
        [InlineKeyboardButton("🧠 Выбрать личность", callback_data="set_personality")],
        [InlineKeyboardButton("🔢 Макс. токенов", callback_data="set_tokens")],
        [InlineKeyboardButton("↩️ Вернуться в меню", callback_data="back_to_menu")]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_personality_keyboard():
    """Клавиатура выбора личности"""
    keyboard = [
        [InlineKeyboardButton("🤖 ChatGPT (по умолчанию)", callback_data="pers_Стандартный")],
        [InlineKeyboardButton("👨‍🏫 Учитель", callback_data="pers_Учитель")],
        [InlineKeyboardButton("👨‍🔬 Ученый", callback_data="pers_Ученый")],
        [InlineKeyboardButton("😊 Друг", callback_data="pers_Друг")],
        [InlineKeyboardButton("🎨 Креативщик", callback_data="pers_Креативщик")],
        [InlineKeyboardButton("💼 Консультант", callback_data="pers_Консультант")],
        [InlineKeyboardButton("↩️ Назад", callback_data="back_settings")]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_temperature_keyboard():
    """Клавиатура выбора температуры"""
    keyboard = [
        [InlineKeyboardButton("🧊 Точный (0.1)", callback_data="temp_0.1"),
         InlineKeyboardButton("⚖️ Сбалансированный (0.7)", callback_data="temp_0.7")],
        [InlineKeyboardButton("💡 Креативный (1.0)", callback_data="temp_1.0"),
         InlineKeyboardButton("🎭 Очень креативный (1.5)", callback_data="temp_1.5")],
        [InlineKeyboardButton("🚀 Максимальный (2.0)", callback_data="temp_2.0")],
        [InlineKeyboardButton("↩️ Назад", callback_data="back_settings")]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_tokens_keyboard():
    """Клавиатура выбора токенов"""
    keyboard = [
        [InlineKeyboardButton("Короткий (512)", callback_data="tokens_512"),
         InlineKeyboardButton("Средний (1024)", callback_data="tokens_1024")],
        [InlineKeyboardButton("Длинный (2048)", callback_data="tokens_2048"),
         InlineKeyboardButton("Очень длинный (4096)", callback_data="tokens_4096")],
        [InlineKeyboardButton("↩️ Назад", callback_data="back_settings")]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_admin_keyboard():
    """Клавиатура администратора"""
    keyboard = [
        [InlineKeyboardButton("📊 Статистика", callback_data="admin_stats"),
         InlineKeyboardButton("👥 Пользователи", callback_data="admin_users")],
        [InlineKeyboardButton("💬 Сообщения", callback_data="admin_messages"),
         InlineKeyboardButton("🔍 Поиск", callback_data="admin_search")],
        [InlineKeyboardButton("📤 Экспорт данных", callback_data="admin_export"),
         InlineKeyboardButton("📢 Рассылка", callback_data="admin_broadcast")],
        [InlineKeyboardButton("↩️ Главное меню", callback_data="back_to_menu")]
    ]
    return InlineKeyboardMarkup(keyboard)

# ============ ФУНКЦИЯ ДЛЯ ЗАПРОСА К API ============

async def get_ai_response(messages, temperature, max_tokens):
    """Получение ответа от AI API"""
    
    if TEST_MODE:
        # Тестовый режим - имитация ответа
        await asyncio.sleep(1)
        
        test_responses = [
            "Привет! Я ChatGPT, ваш AI-ассистент. Чем могу помочь?",
            "Это демонстрационный ответ. Для работы с реальным AI настройте API ключ.",
            "Я готов ответить на ваши вопросы! Пожалуйста, задайте ваш вопрос."
        ]
        import random
        return random.choice(test_responses), 50
    
    headers = {
        "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
        "Content-Type": "application/json"
    }
    
    data = {
        "model": DEFAULT_MODEL,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "stream": False
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                "https://api.deepseek.com/v1/chat/completions",
                headers=headers,
                json=data,
                timeout=30
            ) as response:
                
                if response.status == 200:
                    result = await response.json()
                    if "choices" in result and len(result["choices"]) > 0:
                        message_content = result["choices"][0]["message"]["content"]
                        tokens_used = result.get("usage", {}).get("total_tokens", 0)
                        return message_content, tokens_used
                    else:
                        raise Exception("Нет choices в ответе API")
                else:
                    error_text = await response.text()
                    logger.error(f"API Error {response.status}: {error_text}")
                    raise Exception(f"API Error {response.status}")
                    
    except asyncio.TimeoutError:
        logger.error("Таймаут при запросе к API")
        raise Exception("Таймаут при запросе")
    except Exception as e:
        logger.error(f"Ошибка при запросе к API: {e}")
        raise

# ============ ОСНОВНЫЕ КОМАНДЫ ============

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /start - начало работы"""
    user = update.effective_user
    user_id = user.id
    
    db.add_user(
        user_id=user_id,
        username=user.username,
        first_name=user.first_name,
        last_name=user.last_name
    )
    
    if TEST_MODE:
        mode_notice = "\n\n⚠️ *ДЕМО-РЕЖИМ*\nДля подключения AI требуется API ключ."
    else:
        mode_notice = ""
    
    welcome_message = f"""
🤖 *Добро пожаловать в ChatGPT!*

Привет, {user.first_name}! Я - виртуальный помощник на основе искусственного интеллекта, созданный для помощи в решении различных задач.

*Что я умею:*
• Отвечать на вопросы и объяснять сложные темы
• Помогать с учебой и работой
• Генерировать текст и идеи
• Анализировать информацию
• Поддерживать беседу на любые темы
{mode_notice}

*Используйте кнопки ниже для навигации или просто напишите мне сообщение!*
"""
    
    await update.message.reply_text(
        welcome_message, 
        reply_markup=get_main_keyboard(),
        parse_mode='Markdown'
    )

async def about_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда 'О боте' - описание"""
    about_text = """
*🤖 ChatGPT Telegram Bot*

*Версия:* 1.0.0
*Разработчик:* OpenAI (эмуляция)
*Модель AI:* DeepSeek / ChatGPT-like

*Возможности:*
• 🧠 Понимание естественного языка
• 📚 Обучение и объяснение тем
• 💡 Генерация идей и решений
• 🔍 Анализ информации
• 📝 Помощь с текстами

*Технические особенности:*
• Настройка температуры (креативность)
• Выбор стиля общения (личности)
• Сохранение контекста диалога
• История сообщений
• Админ-панель для анализа

*Для связи с администратором:* используйте команду /admin

*Приятного общения!* 🚀
"""
    
    keyboard = [
        [InlineKeyboardButton("⚙️ Настройки", callback_data="settings"),
         InlineKeyboardButton("❓ Помощь", callback_data="help")],
        [InlineKeyboardButton("↩️ Главное меню", callback_data="back_to_menu")]
    ]
    
    await update.message.reply_text(
        about_text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='Markdown'
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда помощи"""
    help_text = """
*🆘 Помощь по использованию ChatGPT*

*Основные команды:*
• *⚙️ Настройки* - параметры AI
• *🌡 Температура* - креативность ответов (0.1-2.0)
• *🧠 Личность* - стиль общения
• *📜 История* - последние сообщения
• *🗑 Очистить* - начать новый диалог
• *📊 О боте* - информация о боте

*Как пользоваться:*
1. Просто напишите ваш вопрос в чат
2. Используйте кнопки для быстрого доступа
3. Настройте параметры под свои нужды

*Примеры запросов:*
• "Объясни квантовую физику"
• "Напиши план сочинения"
• "Помоги с математической задачей"
• "Придумай идею для проекта"

*💡 Советы:*
• Низкая температура = точные ответы
• Высокая температура = креативные идеи
• Очищайте историю для новых тем
"""
    
    await update.message.reply_text(
        help_text,
        reply_markup=get_main_keyboard(),
        parse_mode='Markdown'
    )

async def settings_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда настроек"""
    user_id = update.effective_user.id
    user_settings = db.get_user_settings(user_id)
    
    if not user_settings:
        user_settings = {
            'temperature': DEFAULT_TEMPERATURE,
            'max_tokens': DEFAULT_MAX_TOKENS,
            'personality': 'Стандартный'
        }
    
    settings_text = f"""
*⚙️ Настройки ChatGPT*

*Текущие параметры:*
• 🌡 *Температура:* {user_settings['temperature']} 
  _(влияет на креативность)_
• 🧠 *Личность:* {user_settings['personality']}
• 🔢 *Макс. токенов:* {user_settings['max_tokens']}
  _(длина ответа)_

*Описание параметров:*
• *Температура* - чем выше, тем более креативные и разнообразные ответы
• *Личность* - определяет стиль и подход к ответам
• *Токены* - ограничивают длину ответов (1 токен ≈ 0.75 слова)

Выберите параметр для изменения:
"""
    
    await update.message.reply_text(
        settings_text,
        reply_markup=get_settings_keyboard(),
        parse_mode='Markdown'
    )

async def temperature_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Меню температуры"""
    temperature_text = """
*🌡 Настройка температуры*

*Температура* влияет на креативность ответов:

*🧊 0.1 - Точный режим*
• Детерминированные ответы
• Минимум случайности
• Идеально для фактов

*⚖️ 0.7 - Сбалансированный (по умолчанию)*
• Баланс точности и креативности
• Подходит для большинства задач

*💡 1.0 - Креативный режим*
• Более разнообразные ответы
• Подходит для творческих задач

*🎭 1.5 - Очень креативный*
• Высокая вариативность
• Для генерации идей

*🚀 2.0 - Максимальный*
• Максимальная креативность
• Экспериментальные ответы

Выберите уровень:
"""
    
    await update.message.reply_text(
        temperature_text,
        reply_markup=get_temperature_keyboard(),
        parse_mode='Markdown'
    )

async def personality_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Меню личности"""
    personality_text = """
*🧠 Выбор личности*

*Личность* определяет стиль общения:

*🤖 Стандартный (ChatGPT)*
• Универсальный помощник
• Баланс всех качеств
• Подходит для любых задач

*👨‍🏫 Учитель*
• Объясняет сложные темы просто
• Использует примеры и аналогии
• Обучающий подход

*👨‍🔬 Ученый*
• Точные, фактологические ответы
• Лаконичный и профессиональный
• Научный подход

*😊 Друг*
• Дружелюбный и поддерживающий
• Эмпатичный и понимающий
• Неформальное общение

*🎨 Креативщик*
• Генерирует нестандартные идеи
• Вдохновляющий и оригинальный
• Творческий подход

*💼 Консультант*
• Структурированные рекомендации
• Аналитический подход
• Профессиональные советы

Выберите личность:
"""
    
    await update.message.reply_text(
        personality_text,
        reply_markup=get_personality_keyboard(),
        parse_mode='Markdown'
    )

async def tokens_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Меню токенов"""
    tokens_text = """
*🔢 Настройка длины ответов*

*Токены* ограничивают длину ответов:

*Короткий (512 токенов)*
• Краткие, лаконичные ответы
• ~384 слова
• Для быстрых вопросов

*Средний (1024 токена)*
• Стандартные ответы
• ~768 слов
• Для большинства задач

*Длинный (2048 токенов)*
• Подробные, развернутые ответы
• ~1536 слов
• Для сложных объяснений

*Очень длинный (4096 токенов)*
• Максимально подробные ответы
• ~3072 слова
• Для больших текстов

Выберите длину ответов:
"""
    
    await update.message.reply_text(
        tokens_text,
        reply_markup=get_tokens_keyboard(),
        parse_mode='Markdown'
    )

async def history_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать историю"""
    user_id = update.effective_user.id
    messages = db.get_user_messages(user_id, limit=10)
    
    if not messages:
        history_text = "*📜 История диалога*\n\nДиалог пуст. Начните общение!"
    else:
        history_text = "*📜 История диалога*\n\n*Последние сообщения:*\n\n"
        for i, (role, message_text, timestamp) in enumerate(messages, 1):
            role_emoji = "👤 Вы" if role == "user" else "🤖 ChatGPT"
            short_msg = message_text[:60] + "..." if len(message_text) > 60 else message_text
            history_text += f"*{i}. {role_emoji}* ({timestamp[11:16]})\n"
            history_text += f"`{short_msg}`\n\n"
    
    keyboard = [
        [InlineKeyboardButton("🗑 Очистить историю", callback_data="clear_confirm"),
         InlineKeyboardButton("↩️ Назад", callback_data="back_settings")]
    ]
    
    await update.message.reply_text(
        history_text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='Markdown'
    )

async def clear_chat_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Очистка чата"""
    clear_text = """
*🗑 Очистка истории диалога*

⚠️ *Внимание!* Это действие:
• Удалит историю текущего диалога
• Начнет новый чистый чат
• Сохранит настройки пользователя

*Что будет сохранено:*
✓ Настройки температуры
✓ Выбранная личность
✓ Максимальные токены

*Что будет удалено:*
✗ История сообщений
✗ Контекст текущего диалога

Вы уверены, что хотите очистить историю?
"""
    
    keyboard = [
        [InlineKeyboardButton("✅ Да, очистить", callback_data="clear_yes"),
         InlineKeyboardButton("❌ Нет, отмена", callback_data="clear_no")]
    ]
    
    await update.message.reply_text(
        clear_text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='Markdown'
    )

async def new_chat_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Новый чат"""
    await update.message.reply_text(
        "*💬 Новый чат*\n\n"
        "Начнем новую беседу! Я готов ответить на ваши вопросы.\n\n"
        "*💡 Совет:* Используйте кнопки ниже для настройки параметров.",
        reply_markup=get_main_keyboard(),
        parse_mode='Markdown'
    )

# ============ ОБРАБОТКА СООБЩЕНИЙ ============

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка текстовых сообщений"""
    user_id = update.effective_user.id
    user_message = update.message.text
    
    # Игнорируем команды из кнопок (они обрабатываются отдельно)
    if user_message in ["⚙️ Настройки", "❓ Помощь", "🌡 Температура", "🧠 Личность", 
                       "📜 История", "🗑 Очистить", "📊 О боте", "💬 Новый чат"]:
        if user_message == "⚙️ Настройки":
            await settings_command(update, context)
        elif user_message == "❓ Помощь":
            await help_command(update, context)
        elif user_message == "🌡 Температура":
            await temperature_menu(update, context)
        elif user_message == "🧠 Личность":
            await personality_menu(update, context)
        elif user_message == "📜 История":
            await history_command(update, context)
        elif user_message == "🗑 Очистить":
            await clear_chat_command(update, context)
        elif user_message == "📊 О боте":
            await about_command(update, context)
        elif user_message == "💬 Новый чат":
            await new_chat_command(update, context)
        return
    
    # Сохраняем сообщение пользователя
    db.save_message(user_id, "user", user_message)
    
    # Отправляем статус "печатает"
    try:
        await context.bot.send_chat_action(
            chat_id=update.effective_chat.id, 
            action="typing"
        )
    except:
        pass
    
    # Получаем настройки пользователя
    settings = db.get_user_settings(user_id)
    if not settings:
        settings = {
            'temperature': DEFAULT_TEMPERATURE,
            'max_tokens': DEFAULT_MAX_TOKENS,
            'personality': 'Стандартный'
        }
    
    # Формируем системный промпт в зависимости от личности
    personality_prompts = {
        'Стандартный': DEFAULT_SYSTEM_PROMPT,
        'Учитель': "Ты - опытный учитель и преподаватель. Ты объясняешь сложные темы простыми словами, используешь аналогии и примеры. Ты терпеливый и понятный.",
        'Ученый': "Ты - строгий ученый и исследователь. Ты даешь точные, фактологические ответы основанные на данных. Ты лаконичен и профессиональен.",
        'Друг': "Ты - близкий друг и доверенное лицо. Ты поддерживаешь, даешь советы и проявляешь эмпатию. Ты дружелюбный и понимающий.",
        'Креативщик': "Ты - творческий гений и генератор идей. Ты придумываешь нестандартные решения, вдохновляешь и создаешь оригинальные концепции.",
        'Консультант': "Ты - профессиональный консультант и эксперт. Ты анализируешь ситуацию, даешь структурированные рекомендации и практические советы."
    }
    
    system_prompt = personality_prompts.get(settings['personality'], DEFAULT_SYSTEM_PROMPT)
    
    # Получаем историю для контекста
    history_messages = db.get_user_messages(user_id, limit=6)
    
    # Формируем сообщения для API
    messages = [{"role": "system", "content": system_prompt}]
    
    # Добавляем историю (исключая самое последнее сообщение)
    for role, message_text, _ in history_messages[:-1]:
        messages.append({
            "role": "user" if role == "user" else "assistant",
            "content": message_text
        })
    
    # Добавляем текущее сообщение
    messages.append({"role": "user", "content": user_message})
    
    try:
        # Отправляем сообщение "обрабатываю"
        processing_msg = await update.message.reply_text(
            "*🤔 Обрабатываю запрос...*",
            parse_mode='Markdown'
        )
        
        # Получаем ответ от AI
        bot_response, tokens_used = await get_ai_response(
            messages=messages,
            temperature=settings['temperature'],
            max_tokens=settings['max_tokens']
        )
        
        # Удаляем сообщение "обрабатываю"
        await processing_msg.delete()
        
        # Сохраняем ответ бота
        db.save_message(user_id, "assistant", bot_response)
        
        # Отправляем ответ с красивым форматированием
        await update.message.reply_text(
            f"{bot_response}\n\n*🤖 ChatGPT | Температура: {settings['temperature']} | Личность: {settings['personality']}*",
            parse_mode='Markdown',
            reply_markup=get_main_keyboard()
        )
        
    except Exception as e:
        logger.error(f"Ошибка при обработке сообщения: {e}")
        
        try:
            # Пробуем удалить сообщение "обрабатываю", если оно есть
            if 'processing_msg' in locals():
                await processing_msg.delete()
        except:
            pass
        
        # Отправляем сообщение об ошибке
        error_responses = [
            "Извините, возникла ошибка при обработке вашего запроса. Пожалуйста, попробуйте еще раз.",
            "Произошла техническая ошибка. Убедитесь, что соединение стабильно, и попробуйте снова.",
            "К сожалению, сервис временно недоступен. Пожалуйста, повторите запрос через несколько минут."
        ]
        
        import random
        error_response = random.choice(error_responses)
        
        await update.message.reply_text(
            f"*❌ Ошибка*\n\n{error_response}",
            parse_mode='Markdown',
            reply_markup=get_main_keyboard()
        )

# ============ ОБРАБОТКА КНОПОК ============

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик inline-кнопок"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    data = query.data
    
    # Температура
    if data.startswith("temp_"):
        temp_value = float(data.split("_")[1])
        db.update_settings(user_id, temperature=temp_value)
        
        temp_names = {
            0.1: "Точный (0.1)",
            0.7: "Сбалансированный (0.7)",
            1.0: "Креативный (1.0)",
            1.5: "Очень креативный (1.5)",
            2.0: "Максимальный (2.0)"
        }
        
        await query.edit_message_text(
            f"*✅ Температура установлена:* {temp_names.get(temp_value, temp_value)}\n\n"
            f"Теперь ответы будут более {['точными', 'сбалансированными', 'креативными', 'очень креативными', 'экспериментальными'][int(temp_value*2)]}.",
            parse_mode='Markdown',
            reply_markup=get_settings_keyboard()
        )
    
    # Личность
    elif data.startswith("pers_"):
        personality = data.split("_", 1)[1]
        db.update_settings(user_id, personality=personality)
        
        personality_descriptions = {
            "Стандартный": "универсальный помощник для любых задач",
            "Учитель": "объясняет сложные темы простыми словами",
            "Ученый": "дает точные, фактологические ответы",
            "Друг": "поддерживает и дает дружеские советы",
            "Креативщик": "генерирует нестандартные идеи",
            "Консультант": "дает структурированные рекомендации"
        }
        
        await query.edit_message_text(
            f"*✅ Личность установлена:* {personality}\n\n"
            f"Теперь я буду общаться как {personality_descriptions.get(personality, 'помощник')}.",
            parse_mode='Markdown',
            reply_markup=get_settings_keyboard()
        )
    
    # Токены
    elif data.startswith("tokens_"):
        tokens = int(data.split("_")[1])
        db.update_settings(user_id, max_tokens=tokens)
        
        token_names = {
            512: "Короткий (512)",
            1024: "Средний (1024)",
            2048: "Длинный (2048)",
            4096: "Очень длинный (4096)"
        }
        
        await query.edit_message_text(
            f"*✅ Макс. токенов установлено:* {token_names.get(tokens, tokens)}\n\n"
            f"Теперь ответы будут {'краткими' if tokens <= 512 else 'стандартными' if tokens <= 1024 else 'подробными' if tokens <= 2048 else 'очень подробными'}.",
            parse_mode='Markdown',
            reply_markup=get_settings_keyboard()
        )
    
    # Навигация
    elif data == "settings":
        await settings_command(update, context)
    
    elif data == "set_temp":
        await temperature_menu(update, context)
    
    elif data == "set_personality":
        await personality_menu(update, context)
    
    elif data == "set_tokens":
        await tokens_menu(update, context)
    
    elif data == "back_settings":
        await settings_command(update, context)
    
    elif data == "back_to_menu":
        await query.edit_message_text(
            "*🏠 Главное меню*\n\nВыберите действие или просто напишите ваш вопрос:",
            parse_mode='Markdown',
            reply_markup=get_main_keyboard()
        )
    
    elif data == "help":
        await help_command(update, context)
    
    # История и очистка
    elif data == "clear_confirm":
        await clear_chat_command(update, context)
    
    elif data == "clear_yes":
        # Здесь можно добавить очистку истории
        await query.edit_message_text(
            "*✅ История очищена*\n\nНачнем новый диалог! Задайте ваш вопрос:",
            parse_mode='Markdown',
            reply_markup=get_main_keyboard()
        )
    
    elif data == "clear_no":
        await query.edit_message_text(
            "*❌ Очистка отменена*\n\nИстория диалога сохранена.",
            parse_mode='Markdown',
            reply_markup=get_main_keyboard()
        )

# ============ АДМИН-КОМАНДЫ ============

async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда админ-панели"""
    user_id = update.effective_user.id
    
    if not is_admin(user_id):
        await update.message.reply_text(
            "*🚫 Доступ запрещен*\n\nУ вас нет прав администратора.",
            parse_mode='Markdown'
        )
        return
    
    admin_text = """
*👨‍💼 Панель администратора*

*Доступные действия:*
• 📊 *Статистика* - общая информация о системе
• 👥 *Пользователи* - список всех пользователей
• 💬 *Сообщения* - последние сообщения в системе
• 🔍 *Поиск* - поиск по сообщениям
• 📤 *Экспорт* - экспорт данных пользователей
• 📢 *Рассылка* - отправка сообщений всем пользователям

Выберите действие:
"""
    
    await update.message.reply_text(
        admin_text,
        reply_markup=get_admin_keyboard(),
        parse_mode='Markdown'
    )

async def admin_stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Статистика системы"""
    user_id = update.effective_user.id
    
    if not is_admin(user_id):
        return
    
    stats = db.get_total_stats()
    
    stats_text = f"""
*📊 Статистика системы*

*👥 Пользователи:*
• Всего: {stats['total_users']}
• Активных (7 дней): {stats['active_users_7d']}

*💬 Сообщения:*
• Всего: {stats['total_messages']}

*📅 Активность за последние 7 дней:*
"""
    
    for day, count in stats['daily_stats'][-7:]:
        stats_text += f"• {day}: {count} сообщений\n"
    
    if TEST_MODE:
        stats_text += "\n*⚠️ РЕЖИМ:* Тестовый (API не настроен)"
    
    await update.message.reply_text(
        stats_text,
        parse_mode='Markdown',
        reply_markup=get_admin_keyboard()
    )

async def admin_users_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Список пользователей"""
    user_id = update.effective_user.id
    
    if not is_admin(user_id):
        return
    
    users = db.get_all_users()
    
    if not users:
        await update.message.reply_text("*📭 Пользователей не найдено*", parse_mode='Markdown')
        return
    
    users_text = "*👥 Последние активные пользователи*\n\n"
    
    for i, user in enumerate(users[:10], 1):
        user_id, username, first_name, last_name, created_at, last_active, msg_count = user
        name = f"{first_name} {last_name}" if last_name else first_name
        username_display = f"@{username}" if username else "без username"
        
        users_text += f"*{i}. {name}* ({username_display})\n"
        users_text += f"   ID: `{user_id}` | Сообщений: {msg_count}\n"
        users_text += f"   Активен: {last_active[:10] if last_active else 'никогда'}\n\n"
    
    await update.message.reply_text(
        users_text,
        parse_mode='Markdown',
        reply_markup=get_admin_keyboard()
    )

async def admin_messages_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Последние сообщения"""
    user_id = update.effective_user.id
    
    if not is_admin(user_id):
        return
    
    messages = db.get_recent_messages(limit=15)
    
    if not messages:
        await update.message.reply_text("*📭 Сообщений не найдено*", parse_mode='Markdown')
        return
    
    messages_text = "*💬 Последние сообщения*\n\n"
    
    for i, msg in enumerate(messages, 1):
        user_id, first_name, username, role, message_text, timestamp = msg
        role_emoji = "👤" if role == "user" else "🤖"
        name = first_name or username or f"ID:{user_id}"
        short_msg = message_text[:40] + "..." if len(message_text) > 40 else message_text
        
        messages_text += f"*{i}. {role_emoji} {name}*\n"
        messages_text += f"   `{short_msg}`\n"
        messages_text += f"   📅 {timestamp[:19]}\n\n"
    
    await update.message.reply_text(
        messages_text,
        parse_mode='Markdown',
        reply_markup=get_admin_keyboard()
    )

async def admin_search_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Поиск по сообщениям"""
    user_id = update.effective_user.id
    
    if not is_admin(user_id):
        return
    
    if not context.args:
        await update.message.reply_text(
            "*🔍 Поиск по сообщениям*\n\n"
            "Использование: `/search <текст>`\n"
            "Пример: `/search математика`",
            parse_mode='Markdown'
        )
        return
    
    keyword = ' '.join(context.args)
    results = db.search_messages(keyword, limit=15)
    
    if not results:
        await update.message.reply_text(
            f"*🔍 По запросу '{keyword}' ничего не найдено*",
            parse_mode='Markdown'
        )
        return
    
    search_text = f"*🔍 Результаты поиска: '{keyword}'*\n\n"
    
    for i, msg in enumerate(results, 1):
        user_id, first_name, username, role, message_text, timestamp = msg
        role_emoji = "👤" if role == "user" else "🤖"
        name = first_name or username or f"ID:{user_id}"
        
        # Поиск и выделение ключевого слова
        msg_lower = message_text.lower()
        keyword_lower = keyword.lower()
        idx = msg_lower.find(keyword_lower)
        
        if idx >= 0:
            start = max(0, idx - 20)
            end = min(len(message_text), idx + len(keyword) + 20)
            snippet = message_text[start:end]
            if start > 0:
                snippet = "..." + snippet
            if end < len(message_text):
                snippet = snippet + "..."
            
            # Выделение ключевого слова жирным (используем Markdown)
            snippet = snippet.replace(keyword, f"*{keyword}*")
        else:
            snippet = message_text[:60] + "..." if len(message_text) > 60 else message_text
        
        search_text += f"*{i}. {role_emoji} {name}*\n"
        search_text += f"   {snippet}\n"
        search_text += f"   📅 {timestamp[:19]}\n\n"
    
    await update.message.reply_text(
        search_text,
        parse_mode='Markdown',
        reply_markup=get_admin_keyboard()
    )

async def admin_button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик админ-кнопок"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    if not is_admin(user_id):
        await query.edit_message_text("*🚫 Доступ запрещен*", parse_mode='Markdown')
        return
    
    data = query.data
    
    if data == "admin_stats":
        await admin_stats_command(update, context)
    
    elif data == "admin_users":
        await admin_users_command(update, context)
    
    elif data == "admin_messages":
        await admin_messages_command(update, context)
    
    elif data == "admin_search":
        await query.edit_message_text(
            "*🔍 Поиск по сообщениям*\n\n"
            "Отправьте команду: `/search <текст>`",
            parse_mode='Markdown',
            reply_markup=get_admin_keyboard()
        )
    
    elif data == "admin_export":
        await query.edit_message_text(
            "*📤 Экспорт данных*\n\n"
            "Использование: `/export <ID пользователя>`\n"
            "Пример: `/export 123456789`",
            parse_mode='Markdown',
            reply_markup=get_admin_keyboard()
        )
    
    elif data == "admin_broadcast":
        await query.edit_message_text(
            "*📢 Рассылка сообщений*\n\n"
            "Использование: `/broadcast <текст сообщения>`\n"
            "Пример: `/broadcast Всем привет!`",
            parse_mode='Markdown',
            reply_markup=get_admin_keyboard()
        )

# ============ ДОПОЛНИТЕЛЬНЫЕ КОМАНДЫ ============

async def export_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Экспорт данных пользователя"""
    user_id = update.effective_user.id
    
    if not is_admin(user_id):
        return
    
    if context.args:
        try:
            target_user_id = int(context.args[0])
            data = db.export_user_data(target_user_id)
            
            if not data['user_info']:
                await update.message.reply_text("*❌ Пользователь не найден*", parse_mode='Markdown')
                return
            
            user_info = data['user_info']
            
            export_text = f"""
*📁 Данные пользователя ID: {target_user_id}*

*👤 Информация:*
• Имя: {user_info[2]} {user_info[3] if user_info[3] else ''}
• Дата регистрации: {user_info[4]}
• Сообщений: {user_info[6]}
"""
            
            await update.message.reply_text(
                export_text,
                parse_mode='Markdown',
                reply_markup=get_admin_keyboard()
            )
            
        except ValueError:
            await update.message.reply_text("*❌ Неверный ID пользователя*", parse_mode='Markdown')
    else:
        await update.message.reply_text(
            "*📤 Экспорт данных*\n\n"
            "Использование: `/export <ID пользователя>`",
            parse_mode='Markdown'
        )

async def broadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Рассылка сообщений"""
    user_id = update.effective_user.id
    
    if not is_admin(user_id):
        return
    
    if not context.args:
        await update.message.reply_text(
            "*📢 Рассылка сообщений*\n\n"
            "Использование: `/broadcast <текст сообщения>`",
            parse_mode='Markdown'
        )
        return
    
    message = ' '.join(context.args)
    users = db.get_all_users()
    
    if not users:
        await update.message.reply_text("*❌ Нет пользователей для рассылки*", parse_mode='Markdown')
        return
    
    sent_count = 0
    failed_count = 0
    
    progress_msg = await update.message.reply_text(
        f"*📤 Начинаю рассылку...*\n0/{len(users)} пользователей",
        parse_mode='Markdown'
    )
    
    for user in users:
        try:
            await context.bot.send_message(
                chat_id=user[0],
                text=f"*📢 Сообщение от администратора*\n\n{message}",
                parse_mode='Markdown'
            )
            sent_count += 1
        except:
            failed_count += 1
        
        # Обновляем прогресс
        if (sent_count + failed_count) % 5 == 0:
            await progress_msg.edit_text(
                f"*📤 Рассылка...*\n{sent_count + failed_count}/{len(users)}\n"
                f"✅ Успешно: {sent_count}\n"
                f"❌ Ошибок: {failed_count}",
                parse_mode='Markdown'
            )
    
    await progress_msg.edit_text(
        f"*✅ Рассылка завершена*\n\n"
        f"• Всего пользователей: {len(users)}\n"
        f"• Успешно отправлено: {sent_count}\n"
        f"• Не удалось отправить: {failed_count}",
        parse_mode='Markdown',
        reply_markup=get_admin_keyboard()
    )

# ============ ГЛАВНАЯ ФУНКЦИЯ ============

def main():
    """Основная функция"""
    # Создаем приложение
    application = Application.builder().token(TELEGRAM_TOKEN).build()
    
    # Регистрируем команды с кнопками
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("settings", settings_command))
    application.add_handler(CommandHandler("temperature", temperature_menu))
    application.add_handler(CommandHandler("personality", personality_menu))
    application.add_handler(CommandHandler("history", history_command))
    application.add_handler(CommandHandler("clear", clear_chat_command))
    application.add_handler(CommandHandler("about", about_command))
    application.add_handler(CommandHandler("newchat", new_chat_command))
    
    # Админ-команды
    application.add_handler(CommandHandler("admin", admin_command))
    application.add_handler(CommandHandler("admin_stats", admin_stats_command))
    application.add_handler(CommandHandler("admin_users", admin_users_command))
    application.add_handler(CommandHandler("admin_messages", admin_messages_command))
    application.add_handler(CommandHandler("search", admin_search_command))
    application.add_handler(CommandHandler("export", export_command))
    application.add_handler(CommandHandler("broadcast", broadcast_command))
    
    # Обработчики кнопок
    application.add_handler(CallbackQueryHandler(button_handler))
    application.add_handler(CallbackQueryHandler(admin_button_handler, pattern="^admin_"))
    
    # Обработчик текстовых сообщений (должен быть последним!)
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    # Запуск бота
    print("🤖 ChatGPT Bot запущен!")
    print("=" * 40)
    print(f"👥 Администраторы: {ADMIN_IDS}")
    
    if TEST_MODE:
        print("⚠️ РЕЖИМ: Тестовый (API не настроен)")
        print("   Добавьте DEEPSEEK_API_KEY в .env для подключения AI")
    else:
        print("✅ API ключ настроен")
    
    print("📊 Консольная админ-панель: python admin_console.py")
    print("=" * 40)
    
    # Запускаем бота
    application.run_polling(allowed_updates=None, drop_pending_updates=True)

if __name__ == '__main__':
    main()