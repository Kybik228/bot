import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # Токен бота Telegram
    TELEGRAM_TOKEN = os.getenv('TELEGRAM_TOKEN')
    
    # API ключ DeepSeek
    DEEPSEEK_API_KEY = os.getenv('DEEPSEEK_API_KEY')
    
    # URL API DeepSeek
    DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions"
    
    # Администраторы (через запятую)
    ADMIN_IDS = [int(id.strip()) for id in os.getenv('ADMIN_IDS', '').split(',') if id.strip()]
    
    # Модель по умолчанию
    DEFAULT_MODEL = "deepseek-chat"
    DEFAULT_TEMPERATURE = 0.7
    DEFAULT_MAX_TOKENS = 2048
    DEFAULT_SYSTEM_PROMPT = "Ты полезный, дружелюбный и умный ассистент."