import sqlite3
from datetime import datetime, timedelta

class Database:
    def __init__(self, db_name='bot_database.db'):
        self.conn = sqlite3.connect(db_name, check_same_thread=False)
        self.create_tables()
    
    def create_tables(self):
        cursor = self.conn.cursor()
        
        # Таблица пользователей
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_active TIMESTAMP,
                message_count INTEGER DEFAULT 0
            )
        ''')
        
        # Таблица сообщений
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                role TEXT,
                message_text TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
        ''')
        
        # Таблица настроек
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_settings (
                user_id INTEGER PRIMARY KEY,
                temperature REAL DEFAULT 0.7,
                max_tokens INTEGER DEFAULT 2048,
                personality TEXT DEFAULT 'Нейтральный',
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
        ''')
        
        self.conn.commit()
    
    def add_user(self, user_id, username, first_name, last_name):
        cursor = self.conn.cursor()
        try:
            cursor.execute('''
                INSERT OR REPLACE INTO users (user_id, username, first_name, last_name, created_at, last_active)
                VALUES (?, ?, ?, ?, COALESCE((SELECT created_at FROM users WHERE user_id = ?), CURRENT_TIMESTAMP), CURRENT_TIMESTAMP)
            ''', (user_id, username, first_name, last_name, user_id))
            
            cursor.execute('''
                INSERT OR IGNORE INTO user_settings (user_id) VALUES (?)
            ''', (user_id,))
            
            self.conn.commit()
            return True
        except Exception as e:
            print(f"Ошибка добавления пользователя: {e}")
            return False
    
    def save_message(self, user_id, role, message_text):
        cursor = self.conn.cursor()
        
        cursor.execute('''
            INSERT INTO messages (user_id, role, message_text)
            VALUES (?, ?, ?)
        ''', (user_id, role, message_text))
        
        cursor.execute('''
            UPDATE users 
            SET last_active = CURRENT_TIMESTAMP,
                message_count = message_count + 1
            WHERE user_id = ?
        ''', (user_id,))
        
        self.conn.commit()
        return cursor.lastrowid
    
    def get_user_messages(self, user_id, limit=100):
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT role, message_text, timestamp
            FROM messages
            WHERE user_id = ?
            ORDER BY timestamp DESC
            LIMIT ?
        ''', (user_id, limit))
        return cursor.fetchall()
    
    def get_all_users(self):
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT user_id, username, first_name, last_name, 
                   created_at, last_active, message_count
            FROM users
            ORDER BY last_active DESC
        ''')
        return cursor.fetchall()
    
    def get_user_stats(self, user_id):
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT u.*, us.temperature, us.personality
            FROM users u
            LEFT JOIN user_settings us ON u.user_id = us.user_id
            WHERE u.user_id = ?
        ''', (user_id,))
        return cursor.fetchone()
    
    def get_total_stats(self):
        cursor = self.conn.cursor()
        
        cursor.execute('SELECT COUNT(*) FROM users')
        total_users = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(*) FROM messages')
        total_messages = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(DISTINCT user_id) FROM messages WHERE timestamp > datetime("now", "-7 days")')
        active_users_7d = cursor.fetchone()[0]
        
        cursor.execute('''
            SELECT date(timestamp) as day, COUNT(*) as count
            FROM messages
            WHERE timestamp > datetime("now", "-30 days")
            GROUP BY day
            ORDER BY day
        ''')
        daily_stats = cursor.fetchall()
        
        return {
            'total_users': total_users,
            'total_messages': total_messages,
            'active_users_7d': active_users_7d,
            'daily_stats': daily_stats
        }
    
    def search_messages(self, keyword, limit=50):
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT m.user_id, u.first_name, u.username, m.role, m.message_text, m.timestamp
            FROM messages m
            JOIN users u ON m.user_id = u.user_id
            WHERE m.message_text LIKE ?
            ORDER BY m.timestamp DESC
            LIMIT ?
        ''', (f'%{keyword}%', limit))
        return cursor.fetchall()
    
    def get_user_settings(self, user_id):
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT temperature, max_tokens, personality
            FROM user_settings
            WHERE user_id = ?
        ''', (user_id,))
        result = cursor.fetchone()
        if result:
            return {
                'temperature': result[0],
                'max_tokens': result[1],
                'personality': result[2]
            }
        return None
    
    def update_settings(self, user_id, **kwargs):
        cursor = self.conn.cursor()
        
        if not kwargs:
            return False
        
        set_clause = ', '.join([f"{key} = ?" for key in kwargs.keys()])
        values = list(kwargs.values())
        values.append(user_id)
        
        query = f'''
            UPDATE user_settings
            SET {set_clause}
            WHERE user_id = ?
        '''
        
        cursor.execute(query, values)
        self.conn.commit()
        return cursor.rowcount > 0
    
    def get_recent_messages(self, limit=100):
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT m.user_id, u.first_name, u.username, m.role, m.message_text, m.timestamp
            FROM messages m
            JOIN users u ON m.user_id = u.user_id
            ORDER BY m.timestamp DESC
            LIMIT ?
        ''', (limit,))
        return cursor.fetchall()
    
    def export_user_data(self, user_id):
        cursor = self.conn.cursor()
        
        user_info = self.get_user_stats(user_id)
        messages = self.get_user_messages(user_id, limit=1000)
        settings = self.get_user_settings(user_id)
        
        return {
            'user_info': user_info,
            'settings': settings,
            'messages': messages
        }
    
    def close(self):
        self.conn.close()